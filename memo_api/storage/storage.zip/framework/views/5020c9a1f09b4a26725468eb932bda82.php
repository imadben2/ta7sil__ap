<div class="flex gap-2">
    <a href="<?php echo e(route('admin.users.show', $user)); ?>"
       class="text-blue-600 hover:text-blue-900"
       title="عرض التفاصيل">
        <i class="fas fa-eye"></i>
    </a>

    <?php
        $isBanned = isset($user->banned_at) && $user->banned_at !== null;
    ?>

    <?php if($user->is_active && !$isBanned): ?>
        <form action="<?php echo e(route('admin.users.toggle-status', $user)); ?>"
              method="POST"
              class="inline">
            <?php echo csrf_field(); ?>
            <button type="submit"
                    class="text-yellow-600 hover:text-yellow-900"
                    title="تعطيل">
                <i class="fas fa-ban"></i>
            </button>
        </form>
    <?php else: ?>
        <form action="<?php echo e(route('admin.users.toggle-status', $user)); ?>"
              method="POST"
              class="inline">
            <?php echo csrf_field(); ?>
            <button type="submit"
                    class="text-green-600 hover:text-green-900"
                    title="تفعيل">
                <i class="fas fa-check-circle"></i>
            </button>
        </form>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.users.reset-password', $user)); ?>"
          method="POST"
          class="inline">
        <?php echo csrf_field(); ?>
        <button type="submit"
                class="text-indigo-600 hover:text-indigo-900"
                title="إعادة تعيين كلمة المرور">
            <i class="fas fa-key"></i>
        </button>
    </form>
</div>
<?php /**PATH C:\Dev2026\1\memo_api\resources\views/admin/users/partials/actions.blade.php ENDPATH**/ ?>