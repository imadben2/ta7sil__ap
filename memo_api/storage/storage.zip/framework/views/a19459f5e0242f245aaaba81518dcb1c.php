<div class="flex gap-2">
    <a href="<?php echo e(route('admin.subjects.show', $subject)); ?>"
       class="text-blue-600 hover:text-blue-900"
       title="عرض">
        <i class="fas fa-eye"></i>
    </a>
    <a href="<?php echo e(route('admin.subjects.edit', $subject)); ?>"
       class="text-green-600 hover:text-green-900"
       title="تعديل">
        <i class="fas fa-edit"></i>
    </a>
    <form action="<?php echo e(route('admin.subjects.toggle-status', $subject)); ?>"
          method="POST"
          class="inline">
        <?php echo csrf_field(); ?>
        <button type="submit"
                class="text-yellow-600 hover:text-yellow-900"
                title="<?php echo e($subject->is_active ? 'تعطيل' : 'تفعيل'); ?>">
            <i class="fas fa-<?php echo e($subject->is_active ? 'toggle-on' : 'toggle-off'); ?>"></i>
        </button>
    </form>
    <form action="<?php echo e(route('admin.subjects.destroy', $subject)); ?>"
          method="POST"
          class="inline delete-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit"
                class="text-red-600 hover:text-red-900"
                title="حذف">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</div>
<?php /**PATH C:\Dev2026\0\app bac 2\memo_api\resources\views/admin/subjects/partials/actions.blade.php ENDPATH**/ ?>