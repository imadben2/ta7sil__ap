<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Planning d'etude</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 10px;
            line-height: 1.5;
            color: #333;
            background: #fff;
        }

        .container {
            padding: 15px;
        }

        /* Header */
        .header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 3px solid #6366f1;
        }

        .header h1 {
            color: #6366f1;
            font-size: 20px;
            margin-bottom: 5px;
        }

        .header .subtitle {
            color: #666;
            font-size: 12px;
            margin-bottom: 8px;
        }

        .header .date-range {
            margin-top: 8px;
            padding: 8px 15px;
            background: #f3f4f6;
            display: inline-block;
            font-size: 11px;
        }

        /* Stats Table */
        .stats-table {
            width: 100%;
            margin-bottom: 20px;
            border-collapse: collapse;
        }

        .stats-table td {
            width: 25%;
            text-align: center;
            padding: 12px 8px;
            background: #f8fafc;
            border: 1px solid #e5e7eb;
        }

        .stat-value {
            font-size: 18px;
            font-weight: bold;
            color: #6366f1;
            display: block;
            margin-bottom: 3px;
        }

        .stat-label {
            font-size: 9px;
            color: #666;
        }

        /* Day Section */
        .day-section {
            margin-bottom: 15px;
            page-break-inside: avoid;
        }

        .day-header {
            background: #6366f1;
            color: white;
            padding: 8px 12px;
            font-size: 12px;
            font-weight: bold;
        }

        /* Sessions Table */
        .sessions-table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        .sessions-table th {
            background: #f3f4f6;
            padding: 8px 10px;
            text-align: center;
            font-weight: bold;
            font-size: 9px;
            color: #374151;
            border: 1px solid #e5e7eb;
        }

        .sessions-table td {
            padding: 6px 10px;
            border: 1px solid #e5e7eb;
            font-size: 9px;
            text-align: center;
        }

        /* Row colors */
        .row-study {
            background: #fff;
        }

        .row-break {
            background: #ecfdf5;
        }

        .row-prayer {
            background: #fffbeb;
        }

        /* Time */
        .time-cell {
            font-weight: bold;
            color: #6366f1;
            width: 60px;
        }

        /* Subject */
        .subject-cell {
            font-weight: bold;
            color: #4338ca;
        }

        .break-text {
            color: #10b981;
            font-weight: bold;
        }

        .prayer-text {
            color: #f59e0b;
            font-weight: bold;
        }

        /* Duration */
        .duration-cell {
            color: #6b7280;
            width: 50px;
        }

        /* Footer */
        .footer {
            margin-top: 20px;
            text-align: center;
            padding-top: 15px;
            border-top: 2px solid #e5e7eb;
            color: #9ca3af;
            font-size: 9px;
        }

        .footer .logo {
            color: #6366f1;
            font-weight: bold;
            font-size: 12px;
            margin-bottom: 3px;
        }

        .page-break {
            page-break-after: always;
        }

        /* Color indicators */
        .indicator {
            display: inline-block;
            width: 8px;
            height: 8px;
            margin-left: 5px;
            vertical-align: middle;
        }
        .indicator-study { background: #6366f1; }
        .indicator-break { background: #10b981; }
        .indicator-prayer { background: #f59e0b; }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>MEMO - Planificateur Intelligent</h1>
            <div class="subtitle">Planning d'etude personnel</div>
            <div class="date-range">
                Du <?php echo e($startDate->format('d/m/Y')); ?> au <?php echo e($endDate->format('d/m/Y')); ?>

            </div>
        </div>

        <!-- Stats -->
        <table class="stats-table">
            <tr>
                <td>
                    <span class="stat-value"><?php echo e($totalSessions); ?></span>
                    <span class="stat-label">Seances d'etude</span>
                </td>
                <td>
                    <span class="stat-value"><?php echo e($totalBreaks); ?></span>
                    <span class="stat-label">Pauses</span>
                </td>
                <td>
                    <span class="stat-value"><?php echo e(round($totalStudyMinutes / 60, 1)); ?></span>
                    <span class="stat-label">Heures d'etude</span>
                </td>
                <td>
                    <span class="stat-value"><?php echo e($sessionsByDate->count()); ?></span>
                    <span class="stat-label">Jours</span>
                </td>
            </tr>
        </table>

        <!-- Legend -->
        <div style="margin-bottom: 15px; font-size: 9px; text-align: center;">
            <span class="indicator indicator-study"></span> Etude
            <span style="margin-left: 15px;"><span class="indicator indicator-break"></span> Pause</span>
            <span style="margin-left: 15px;"><span class="indicator indicator-prayer"></span> Priere</span>
        </div>

        <!-- Sessions by Day -->
        <?php $__currentLoopData = $sessionsByDate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $daySessions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $dateCarbon = \Carbon\Carbon::parse($date);
                $frenchDays = [
                    'Sunday' => 'Dimanche',
                    'Monday' => 'Lundi',
                    'Tuesday' => 'Mardi',
                    'Wednesday' => 'Mercredi',
                    'Thursday' => 'Jeudi',
                    'Friday' => 'Vendredi',
                    'Saturday' => 'Samedi',
                ];
                $dayName = $frenchDays[$dateCarbon->format('l')] ?? $dateCarbon->format('l');
            ?>

            <div class="day-section">
                <div class="day-header">
                    <?php echo e($dayName); ?> - <?php echo e($dateCarbon->format('d/m/Y')); ?>

                </div>

                <table class="sessions-table">
                    <thead>
                        <tr>
                            <th>Heure</th>
                            <th>Matiere / Activite</th>
                            <th>Duree</th>
                            <th>Contenu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $daySessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $isBreak = $session->is_break ?? false;
                                $contentTitle = $session->content_title ?? '';
                                $isPrayer = mb_strpos($contentTitle, 'صلا') !== false;
                                $rowClass = $isPrayer ? 'row-prayer' : ($isBreak ? 'row-break' : 'row-study');

                                // Get French subject name
                                $subjectName = 'Matiere';
                                if ($session->subject) {
                                    $subjectName = $session->subject->name_fr
                                        ?? $session->subject->name_en
                                        ?? $session->subject->name
                                        ?? 'Matiere';
                                }

                                // Session type translation
                                $sessionTypes = [
                                    'study' => 'Etude',
                                    'revision' => 'Revision',
                                    'practice' => 'Exercices',
                                    'longRevision' => 'Revision approfondie',
                                    'test' => 'Test',
                                    'break' => 'Pause',
                                ];
                                $sessionType = $sessionTypes[$session->session_type ?? 'study'] ?? 'Etude';
                            ?>
                            <tr class="<?php echo e($rowClass); ?>">
                                <td class="time-cell">
                                    <?php echo e(substr($session->scheduled_start_time, 0, 5)); ?>

                                </td>
                                <td>
                                    <?php if($isBreak): ?>
                                        <?php if($isPrayer): ?>
                                            <span class="prayer-text">Priere</span>
                                        <?php else: ?>
                                            <span class="break-text">Pause</span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="subject-cell"><?php echo e($subjectName); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="duration-cell">
                                    <?php echo e($session->duration_minutes); ?> min
                                </td>
                                <td>
                                    <?php if(!$isBreak): ?>
                                        <?php echo e($sessionType); ?>

                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php if(!$loop->last && $loop->iteration % 4 == 0): ?>
                <div class="page-break"></div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- Footer -->
        <div class="footer">
            <div class="logo">MEMO - Planificateur Intelligent</div>
            <div>Genere le <?php echo e($generatedAt->format('d/m/Y')); ?> a <?php echo e($generatedAt->format('H:i')); ?></div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Dev2026\0\app bac 2\memo_api\resources\views/pdf/schedule.blade.php ENDPATH**/ ?>