

<?php $__env->startSection('title', 'الإعدادات'); ?>
<?php $__env->startSection('page-title', 'الإعدادات'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4" style="font-family: 'Cairo', sans-serif; direction: rtl;">
    <!-- Page Header -->
    <div class="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-lg p-8 mb-6">
        <div class="flex items-center justify-between">
            <div class="flex items-center gap-4">
                <div class="w-16 h-16 bg-white bg-opacity-20 rounded-xl flex items-center justify-center">
                    <i class="fas fa-cog text-3xl text-white"></i>
                </div>
                <div>
                    <h1 class="text-3xl font-bold text-white mb-2">الإعدادات</h1>
                    <p class="text-blue-100">إدارة وتخصيص تفضيلاتك الشخصية</p>
                </div>
            </div>
            <a href="<?php echo e(route('admin.profile.index')); ?>" class="px-6 py-3 bg-white bg-opacity-20 hover:bg-opacity-30 text-white rounded-lg font-bold transition-all">
                <i class="fas fa-arrow-right ml-2"></i>
                رجوع
            </a>
        </div>
    </div>

    <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST" id="settingsForm">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="grid grid-cols-12 gap-6">
            <!-- Left Column (Main Settings) - 8 columns -->
            <div class="col-span-12 lg:col-span-8 space-y-6">

                <!-- App Settings (Version Control) -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div class="bg-gradient-to-r from-emerald-500 to-emerald-600 px-6 py-4">
                        <h2 class="text-xl font-bold text-white flex items-center gap-2">
                            <i class="fas fa-mobile-alt"></i>
                            إعدادات التطبيق
                        </h2>
                    </div>

                    <div class="p-6 space-y-4">
                        <!-- Minimum App Version -->
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">الحد الأدنى لإصدار التطبيق</label>
                            <div class="relative">
                                <input type="text" name="min_app_version" value="<?php echo e($appSettings['min_app_version'] ?? '1.0'); ?>"
                                       placeholder="مثال: 1.0 أو 1.2.3"
                                       pattern="^\d+(\.\d+)*$"
                                       class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500">
                                <div class="absolute left-3 top-1/2 transform -translate-y-1/2">
                                    <i class="fas fa-code-branch text-gray-400"></i>
                                </div>
                            </div>
                            <p class="text-sm text-gray-500 mt-2">
                                <i class="fas fa-info-circle text-emerald-500 ml-1"></i>
                                المستخدمون الذين لديهم إصدار أقدم من هذا الرقم سيُطلب منهم تحديث التطبيق
                            </p>
                        </div>

                        <!-- Warning Box -->
                        <div class="bg-amber-50 border border-amber-200 rounded-xl p-4">
                            <div class="flex items-start gap-3">
                                <i class="fas fa-exclamation-triangle text-amber-600 text-xl mt-1"></i>
                                <div>
                                    <h4 class="font-bold text-amber-800 mb-1">تنبيه مهم</h4>
                                    <p class="text-sm text-amber-700">
                                        تغيير هذا الرقم سيمنع المستخدمين الذين لديهم إصدار أقدم من استخدام التطبيق حتى يقوموا بالتحديث.
                                        تأكد من رفع الإصدار الجديد على المتجر قبل تغيير هذا الرقم.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Notifications Settings -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div class="bg-gradient-to-r from-blue-500 to-blue-600 px-6 py-4">
                        <h2 class="text-xl font-bold text-white flex items-center gap-2">
                            <i class="fas fa-bell"></i>
                            إعدادات الإشعارات
                        </h2>
                    </div>

                    <div class="p-6 space-y-4">
                        <!-- Notification Types -->
                        <div>
                            <h3 class="text-lg font-bold text-gray-900 mb-4">أنواع الإشعارات</h3>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <?php
                                    $notificationTypes = [
                                        ['name' => 'notify_new_memo', 'label' => 'محتوى جديد', 'icon' => 'file-alt', 'color' => 'blue'],
                                        ['name' => 'notify_memo_due', 'label' => 'موعد المذاكرة', 'icon' => 'clock', 'color' => 'orange'],
                                        ['name' => 'notify_revision_reminder', 'label' => 'تذكير المراجعة', 'icon' => 'redo', 'color' => 'purple'],
                                        ['name' => 'notify_achievement', 'label' => 'الإنجازات', 'icon' => 'trophy', 'color' => 'yellow'],
                                        ['name' => 'notify_prayer_time', 'label' => 'أوقات الصلاة', 'icon' => 'moon', 'color' => 'green'],
                                        ['name' => 'notify_daily_goal', 'label' => 'الهدف اليومي', 'icon' => 'bullseye', 'color' => 'red'],
                                    ];
                                ?>

                                <?php $__currentLoopData = $notificationTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-all">
                                    <div class="flex items-center gap-3">
                                        <div class="w-10 h-10 bg-<?php echo e($type['color']); ?>-100 rounded-lg flex items-center justify-center">
                                            <i class="fas fa-<?php echo e($type['icon']); ?> text-<?php echo e($type['color']); ?>-600"></i>
                                        </div>
                                        <span class="font-semibold text-gray-800"><?php echo e($type['label']); ?></span>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" name="<?php echo e($type['name']); ?>" value="1"
                                               <?php echo e(($userSettings->{$type['name']} ?? true) ? 'checked' : ''); ?>

                                               class="sr-only peer">
                                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                    </label>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="border-t border-gray-200 my-4"></div>

                        <!-- Notification Channels -->
                        <div>
                            <h3 class="text-lg font-bold text-gray-900 mb-4">قنوات الإشعارات</h3>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <?php
                                    $channels = [
                                        ['name' => 'notify_push', 'label' => 'إشعارات التطبيق', 'icon' => 'mobile-alt', 'color' => 'blue'],
                                        ['name' => 'notify_email', 'label' => 'البريد الإلكتروني', 'icon' => 'envelope', 'color' => 'green'],
                                        ['name' => 'notify_sms', 'label' => 'الرسائل النصية', 'icon' => 'sms', 'color' => 'purple'],
                                    ];
                                ?>

                                <?php $__currentLoopData = $channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-all">
                                    <div class="flex flex-col items-center gap-2 w-full">
                                        <div class="w-12 h-12 bg-<?php echo e($channel['color']); ?>-100 rounded-lg flex items-center justify-center">
                                            <i class="fas fa-<?php echo e($channel['icon']); ?> text-xl text-<?php echo e($channel['color']); ?>-600"></i>
                                        </div>
                                        <span class="font-semibold text-sm text-gray-800"><?php echo e($channel['label']); ?></span>
                                        <label class="relative inline-flex items-center cursor-pointer">
                                            <input type="checkbox" name="<?php echo e($channel['name']); ?>" value="1"
                                                   <?php echo e(($userSettings->{$channel['name']} ?? ($channel['name'] === 'notify_push')) ? 'checked' : ''); ?>

                                                   class="sr-only peer">
                                            <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                        </label>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Prayer Times Settings -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div class="bg-gradient-to-r from-green-500 to-green-600 px-6 py-4">
                        <h2 class="text-xl font-bold text-white flex items-center gap-2">
                            <i class="fas fa-mosque"></i>
                            إعدادات أوقات الصلاة
                        </h2>
                    </div>

                    <div class="p-6 space-y-4">
                        <!-- Enable Prayer Times -->
                        <div class="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                            <div class="flex items-center gap-3">
                                <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-moon text-2xl text-green-600"></i>
                                </div>
                                <div>
                                    <p class="font-bold text-gray-900">تفعيل أوقات الصلاة</p>
                                    <p class="text-sm text-gray-600">عرض أوقات الصلاة في التطبيق</p>
                                </div>
                            </div>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" name="prayer_times_enabled" value="1"
                                       <?php echo e(($userSettings->prayer_times_enabled ?? false) ? 'checked' : ''); ?>

                                       class="sr-only peer" id="prayer-times-toggle">
                                <div class="w-14 h-7 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-green-600"></div>
                            </label>
                        </div>

                        <div id="prayer-settings" class="<?php echo e(($userSettings->prayer_times_enabled ?? false) ? '' : 'hidden'); ?>">
                            <!-- Calculation Method -->
                            <div class="mb-4">
                                <label class="block text-sm font-bold text-gray-700 mb-2">طريقة الحساب</label>
                                <select name="calculation_method" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                    <option value="egyptian" <?php echo e(($userSettings->calculation_method ?? 'egyptian') === 'egyptian' ? 'selected' : ''); ?>>الهيئة العامة المصرية للمساحة</option>
                                    <option value="mwl" <?php echo e(($userSettings->calculation_method ?? '') === 'mwl' ? 'selected' : ''); ?>>رابطة العالم الإسلامي</option>
                                    <option value="isna" <?php echo e(($userSettings->calculation_method ?? '') === 'isna' ? 'selected' : ''); ?>>الجمعية الإسلامية لأمريكا الشمالية</option>
                                    <option value="umm_alqura" <?php echo e(($userSettings->calculation_method ?? '') === 'umm_alqura' ? 'selected' : ''); ?>>أم القرى - مكة المكرمة</option>
                                </select>
                            </div>

                            <!-- Madhab -->
                            <div class="mb-4">
                                <label class="block text-sm font-bold text-gray-700 mb-2">المذهب</label>
                                <div class="grid grid-cols-2 gap-4">
                                    <label class="relative cursor-pointer">
                                        <input type="radio" name="madhab" value="shafi"
                                               <?php echo e(($userSettings->madhab ?? 'shafi') === 'shafi' ? 'checked' : ''); ?>

                                               class="sr-only peer">
                                        <div class="p-4 border-2 border-gray-200 rounded-xl peer-checked:border-green-600 peer-checked:bg-green-50 hover:border-green-300 transition-all text-center">
                                            <span class="font-semibold">الشافعي</span>
                                        </div>
                                    </label>
                                    <label class="relative cursor-pointer">
                                        <input type="radio" name="madhab" value="hanafi"
                                               <?php echo e(($userSettings->madhab ?? '') === 'hanafi' ? 'checked' : ''); ?>

                                               class="sr-only peer">
                                        <div class="p-4 border-2 border-gray-200 rounded-xl peer-checked:border-green-600 peer-checked:bg-green-50 hover:border-green-300 transition-all text-center">
                                            <span class="font-semibold">الحنفي</span>
                                        </div>
                                    </label>
                                </div>
                            </div>

                            <!-- Prayer Notifications -->
                            <div>
                                <label class="block text-sm font-bold text-gray-700 mb-3">إشعارات الصلوات</label>
                                <div class="grid grid-cols-2 md:grid-cols-5 gap-3">
                                    <?php
                                        $prayers = ['fajr' => 'الفجر', 'dhuhr' => 'الظهر', 'asr' => 'العصر', 'maghrib' => 'المغرب', 'isha' => 'العشاء'];
                                    ?>

                                    <?php $__currentLoopData = $prayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex flex-col items-center gap-2 p-3 bg-gray-50 rounded-lg">
                                        <span class="text-sm font-semibold"><?php echo e($name); ?></span>
                                        <label class="relative inline-flex items-center cursor-pointer">
                                            <input type="checkbox" name="notify_<?php echo e($key); ?>" value="1"
                                                   <?php echo e(($userSettings->{'notify_'.$key} ?? false) ? 'checked' : ''); ?>

                                                   class="sr-only peer">
                                            <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-green-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                                        </label>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                <div class="mt-4">
                                    <label class="block text-sm font-bold text-gray-700 mb-2">التنبيه قبل الصلاة بـ</label>
                                    <select name="prayer_notification_before" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 focus:border-green-500">
                                        <option value="5" <?php echo e(($userSettings->prayer_notification_before ?? 15) == 5 ? 'selected' : ''); ?>>5 دقائق</option>
                                        <option value="10" <?php echo e(($userSettings->prayer_notification_before ?? 15) == 10 ? 'selected' : ''); ?>>10 دقائق</option>
                                        <option value="15" <?php echo e(($userSettings->prayer_notification_before ?? 15) == 15 ? 'selected' : ''); ?>>15 دقيقة</option>
                                        <option value="30" <?php echo e(($userSettings->prayer_notification_before ?? 15) == 30 ? 'selected' : ''); ?>>30 دقيقة</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Appearance Settings -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div class="bg-gradient-to-r from-purple-500 to-purple-600 px-6 py-4">
                        <h2 class="text-xl font-bold text-white flex items-center gap-2">
                            <i class="fas fa-palette"></i>
                            إعدادات المظهر
                        </h2>
                    </div>

                    <div class="p-6 space-y-6">
                        <!-- Theme Selection -->
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-3">المظهر</label>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <label class="relative cursor-pointer">
                                    <input type="radio" name="theme" value="light"
                                           <?php echo e(($userSettings->theme ?? 'system') === 'light' ? 'checked' : ''); ?>

                                           class="sr-only peer">
                                    <div class="p-6 border-2 border-gray-200 rounded-xl peer-checked:border-purple-600 peer-checked:bg-purple-50 hover:border-purple-300 transition-all">
                                        <div class="flex flex-col items-center gap-3">
                                            <i class="fas fa-sun text-4xl text-yellow-500"></i>
                                            <span class="font-semibold">فاتح</span>
                                        </div>
                                    </div>
                                </label>

                                <label class="relative cursor-pointer">
                                    <input type="radio" name="theme" value="dark"
                                           <?php echo e(($userSettings->theme ?? 'system') === 'dark' ? 'checked' : ''); ?>

                                           class="sr-only peer">
                                    <div class="p-6 border-2 border-gray-200 rounded-xl peer-checked:border-purple-600 peer-checked:bg-purple-50 hover:border-purple-300 transition-all">
                                        <div class="flex flex-col items-center gap-3">
                                            <i class="fas fa-moon text-4xl text-indigo-600"></i>
                                            <span class="font-semibold">داكن</span>
                                        </div>
                                    </div>
                                </label>

                                <label class="relative cursor-pointer">
                                    <input type="radio" name="theme" value="system"
                                           <?php echo e(($userSettings->theme ?? 'system') === 'system' ? 'checked' : ''); ?>

                                           class="sr-only peer">
                                    <div class="p-6 border-2 border-gray-200 rounded-xl peer-checked:border-purple-600 peer-checked:bg-purple-50 hover:border-purple-300 transition-all">
                                        <div class="flex flex-col items-center gap-3">
                                            <i class="fas fa-adjust text-4xl text-gray-600"></i>
                                            <span class="font-semibold">تلقائي</span>
                                        </div>
                                    </div>
                                </label>
                            </div>
                        </div>

                        <!-- Primary Color -->
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-3">اللون الأساسي</label>
                            <div class="grid grid-cols-4 md:grid-cols-6 gap-3">
                                <?php
                                    $colors = [
                                        'blue' => '#3B82F6',
                                        'green' => '#10B981',
                                        'purple' => '#8B5CF6',
                                        'red' => '#EF4444',
                                        'orange' => '#F97316',
                                        'pink' => '#EC4899',
                                        'indigo' => '#6366F1',
                                        'teal' => '#14B8A6',
                                    ];
                                ?>

                                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $colorName => $colorCode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="relative cursor-pointer">
                                    <input type="radio" name="primary_color" value="<?php echo e($colorName); ?>"
                                           <?php echo e(($userSettings->primary_color ?? 'blue') === $colorName ? 'checked' : ''); ?>

                                           class="sr-only peer">
                                    <div class="w-full h-16 rounded-xl border-4 border-gray-200 peer-checked:border-gray-900 hover:scale-110 transition-all" style="background-color: <?php echo e($colorCode); ?>">
                                        <div class="w-full h-full flex items-center justify-center">
                                            <i class="fas fa-check text-white text-2xl opacity-0 peer-checked:opacity-100"></i>
                                        </div>
                                    </div>
                                </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <!-- Language -->
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-3">لغة الواجهة</label>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <label class="relative cursor-pointer">
                                    <input type="radio" name="language" value="ar"
                                           <?php echo e(($userSettings->language ?? 'ar') === 'ar' ? 'checked' : ''); ?>

                                           class="sr-only peer">
                                    <div class="p-4 border-2 border-gray-200 rounded-xl peer-checked:border-purple-600 peer-checked:bg-purple-50 hover:border-purple-300 transition-all">
                                        <div class="flex items-center gap-3">
                                            <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-2xl">
                                                🇩🇿
                                            </div>
                                            <span class="font-semibold">العربية</span>
                                        </div>
                                    </div>
                                </label>

                                <label class="relative cursor-pointer">
                                    <input type="radio" name="language" value="fr"
                                           <?php echo e(($userSettings->language ?? 'ar') === 'fr' ? 'checked' : ''); ?>

                                           class="sr-only peer">
                                    <div class="p-4 border-2 border-gray-200 rounded-xl peer-checked:border-purple-600 peer-checked:bg-purple-50 hover:border-purple-300 transition-all">
                                        <div class="flex items-center gap-3">
                                            <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-2xl">
                                                🇫🇷
                                            </div>
                                            <span class="font-semibold">Français</span>
                                        </div>
                                    </div>
                                </label>

                                <label class="relative cursor-pointer">
                                    <input type="radio" name="language" value="en"
                                           <?php echo e(($userSettings->language ?? 'ar') === 'en' ? 'checked' : ''); ?>

                                           class="sr-only peer">
                                    <div class="p-4 border-2 border-gray-200 rounded-xl peer-checked:border-purple-600 peer-checked:bg-purple-50 hover:border-purple-300 transition-all">
                                        <div class="flex items-center gap-3">
                                            <div class="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center text-2xl">
                                                🇬🇧
                                            </div>
                                            <span class="font-semibold">English</span>
                                        </div>
                                    </div>
                                </label>
                            </div>
                        </div>

                        <!-- RTL Mode -->
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                            <div class="flex items-center gap-3">
                                <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-align-right text-xl text-purple-600"></i>
                                </div>
                                <div>
                                    <p class="font-bold text-gray-900">وضع RTL</p>
                                    <p class="text-sm text-gray-600">الكتابة من اليمين إلى اليسار</p>
                                </div>
                            </div>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" name="rtl_mode" value="1"
                                       <?php echo e(($userSettings->rtl_mode ?? true) ? 'checked' : ''); ?>

                                       class="sr-only peer">
                                <div class="w-14 h-7 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-purple-600"></div>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Study Settings -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div class="bg-gradient-to-r from-orange-500 to-orange-600 px-6 py-4">
                        <h2 class="text-xl font-bold text-white flex items-center gap-2">
                            <i class="fas fa-book-reader"></i>
                            إعدادات الدراسة
                        </h2>
                    </div>

                    <div class="p-6 space-y-4">
                        <!-- Daily Goal -->
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">الهدف اليومي (بالدقائق)</label>
                            <div class="relative">
                                <input type="number" name="daily_goal_minutes" value="<?php echo e($userSettings->daily_goal_minutes ?? 120); ?>" min="15" max="600" step="15"
                                       class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500">
                                <div class="absolute left-3 top-1/2 transform -translate-y-1/2">
                                    <i class="fas fa-clock text-gray-400"></i>
                                </div>
                            </div>
                            <p class="text-sm text-gray-500 mt-2">الوقت المستهدف للدراسة يومياً</p>
                        </div>

                        <!-- First Day of Week -->
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">أول يوم في الأسبوع</label>
                            <select name="first_day_of_week" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500">
                                <option value="saturday" <?php echo e(($userSettings->first_day_of_week ?? 'saturday') === 'saturday' ? 'selected' : ''); ?>>السبت</option>
                                <option value="sunday" <?php echo e(($userSettings->first_day_of_week ?? 'saturday') === 'sunday' ? 'selected' : ''); ?>>الأحد</option>
                                <option value="monday" <?php echo e(($userSettings->first_day_of_week ?? 'saturday') === 'monday' ? 'selected' : ''); ?>>الاثنين</option>
                            </select>
                        </div>

                        <!-- Show Streak Reminder -->
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                            <div class="flex items-center gap-3">
                                <div class="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                                    <i class="fas fa-fire text-xl text-orange-600"></i>
                                </div>
                                <div>
                                    <p class="font-bold text-gray-900">تذكير السلسلة</p>
                                    <p class="text-sm text-gray-600">إظهار تذكير للحفاظ على سلسلة الأيام</p>
                                </div>
                            </div>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" name="show_streak_reminder" value="1"
                                       <?php echo e(($userSettings->show_streak_reminder ?? true) ? 'checked' : ''); ?>

                                       class="sr-only peer">
                                <div class="w-14 h-7 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-orange-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-orange-600"></div>
                            </label>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column (Quick Settings & Info) - 4 columns -->
            <div class="col-span-12 lg:col-span-4 space-y-6">

                <!-- Quick Actions -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden sticky top-6">
                    <div class="bg-gradient-to-r from-indigo-500 to-indigo-600 px-6 py-4">
                        <h2 class="text-xl font-bold text-white flex items-center gap-2">
                            <i class="fas fa-bolt"></i>
                            إجراءات سريعة
                        </h2>
                    </div>

                    <div class="p-6 space-y-3">
                        <button type="submit" class="w-full px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl font-bold shadow-lg transition-all">
                            <i class="fas fa-save ml-2"></i>
                            حفظ جميع التغييرات
                        </button>

                        <button type="button" onclick="resetSettings()" class="w-full px-6 py-3 border-2 border-gray-300 rounded-xl text-gray-700 hover:bg-gray-50 font-bold transition-all">
                            <i class="fas fa-undo ml-2"></i>
                            إعادة تعيين
                        </button>

                        <a href="<?php echo e(route('admin.profile.index')); ?>" class="block w-full px-6 py-3 border-2 border-gray-300 rounded-xl text-gray-700 hover:bg-gray-50 font-bold transition-all text-center">
                            <i class="fas fa-times ml-2"></i>
                            إلغاء
                        </a>
                    </div>
                </div>

                <!-- Privacy Settings -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div class="bg-gradient-to-r from-red-500 to-red-600 px-6 py-4">
                        <h2 class="text-xl font-bold text-white flex items-center gap-2">
                            <i class="fas fa-shield-alt"></i>
                            الخصوصية
                        </h2>
                    </div>

                    <div class="p-6 space-y-3">
                        <?php
                            $privacySettings = [
                                ['name' => 'profile_public', 'label' => 'الملف العام', 'icon' => 'globe'],
                                ['name' => 'show_statistics', 'label' => 'عرض الإحصائيات', 'icon' => 'chart-bar'],
                                ['name' => 'allow_friend_requests', 'label' => 'طلبات الصداقة', 'icon' => 'user-friends'],
                            ];
                        ?>

                        <?php $__currentLoopData = $privacySettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div class="flex items-center gap-2">
                                <i class="fas fa-<?php echo e($setting['icon']); ?> text-red-600"></i>
                                <span class="text-sm font-semibold"><?php echo e($setting['label']); ?></span>
                            </div>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" name="<?php echo e($setting['name']); ?>" value="1"
                                       <?php echo e(($userSettings->{$setting['name']} ?? ($setting['name'] === 'show_statistics')) ? 'checked' : ''); ?>

                                       class="sr-only peer">
                                <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-red-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-600"></div>
                            </label>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- Data & Storage -->
                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div class="bg-gradient-to-r from-teal-500 to-teal-600 px-6 py-4">
                        <h2 class="text-xl font-bold text-white flex items-center gap-2">
                            <i class="fas fa-database"></i>
                            البيانات والتخزين
                        </h2>
                    </div>

                    <div class="p-6 space-y-4">
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div class="flex items-center gap-2">
                                <i class="fas fa-cloud-upload-alt text-teal-600"></i>
                                <span class="text-sm font-semibold">النسخ الاحتياطي التلقائي</span>
                            </div>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" name="auto_backup" value="1"
                                       <?php echo e(($userSettings->auto_backup ?? false) ? 'checked' : ''); ?>

                                       class="sr-only peer">
                                <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-teal-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-teal-600"></div>
                            </label>
                        </div>

                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div class="flex items-center gap-2">
                                <i class="fas fa-wifi text-teal-600"></i>
                                <span class="text-sm font-semibold">تنزيل عبر Wi-Fi فقط</span>
                            </div>
                            <label class="relative inline-flex items-center cursor-pointer">
                                <input type="checkbox" name="download_on_wifi_only" value="1"
                                       <?php echo e(($userSettings->download_on_wifi_only ?? true) ? 'checked' : ''); ?>

                                       class="sr-only peer">
                                <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-teal-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-teal-600"></div>
                            </label>
                        </div>

                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">تكرار النسخ الاحتياطي</label>
                            <select name="backup_frequency" class="w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-teal-500">
                                <option value="daily" <?php echo e(($userSettings->backup_frequency ?? 'weekly') === 'daily' ? 'selected' : ''); ?>>يومي</option>
                                <option value="weekly" <?php echo e(($userSettings->backup_frequency ?? 'weekly') === 'weekly' ? 'selected' : ''); ?>>أسبوعي</option>
                                <option value="monthly" <?php echo e(($userSettings->backup_frequency ?? 'weekly') === 'monthly' ? 'selected' : ''); ?>>شهري</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- Information Panel -->
                <div class="bg-blue-50 border border-blue-200 rounded-xl p-6">
                    <div class="flex items-start gap-3">
                        <i class="fas fa-info-circle text-blue-600 text-xl mt-1"></i>
                        <div>
                            <h4 class="font-bold text-gray-900 mb-2">معلومات</h4>
                            <ul class="space-y-2 text-sm text-gray-600">
                                <li class="flex items-start gap-2">
                                    <i class="fas fa-check text-blue-600 mt-1"></i>
                                    <span>سيتم حفظ جميع الإعدادات تلقائياً</span>
                                </li>
                                <li class="flex items-start gap-2">
                                    <i class="fas fa-check text-blue-600 mt-1"></i>
                                    <span>التغييرات تُطبق فوراً على جميع الأجهزة</span>
                                </li>
                                <li class="flex items-start gap-2">
                                    <i class="fas fa-check text-blue-600 mt-1"></i>
                                    <span>يمكنك إعادة تعيين الإعدادات إلى الوضع الافتراضي في أي وقت</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
// Prayer times toggle
document.getElementById('prayer-times-toggle').addEventListener('change', function() {
    const prayerSettings = document.getElementById('prayer-settings');
    if (this.checked) {
        prayerSettings.classList.remove('hidden');
    } else {
        prayerSettings.classList.add('hidden');
    }
});

// Reset settings
function resetSettings() {
    if (confirm('هل أنت متأكد من إعادة تعيين جميع الإعدادات إلى الوضع الافتراضي؟')) {
        // Reload the page
        window.location.reload();
    }
}

// Form submission with loading state
document.getElementById('settingsForm').addEventListener('submit', function(e) {
    const submitButton = this.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin ml-2"></i>جاري الحفظ...';
});

// Auto-save notification (optional)
let saveTimeout;
const formInputs = document.querySelectorAll('#settingsForm input, #settingsForm select');
formInputs.forEach(input => {
    input.addEventListener('change', function() {
        clearTimeout(saveTimeout);
        // Show indicator that changes are pending
        const submitButton = document.querySelector('button[type="submit"]');
        submitButton.classList.add('animate-pulse');

        saveTimeout = setTimeout(() => {
            submitButton.classList.remove('animate-pulse');
        }, 2000);
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Dev2026\0\app bac 2\memo_api\resources\views/admin/profile/settings.blade.php ENDPATH**/ ?>