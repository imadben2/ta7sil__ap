<?php $__env->startSection('title', 'إضافة عرض ترويجي جديد'); ?>
<?php $__env->startSection('page-title', 'إضافة عرض ترويجي جديد'); ?>
<?php $__env->startSection('page-description', 'إنشاء شريحة ترويجية جديدة للصفحة الرئيسية'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <form action="<?php echo e(route('admin.promos.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
        <?php echo csrf_field(); ?>

        <!-- Basic Info Card -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <h3 class="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
                <i class="fas fa-info-circle text-blue-500"></i>
                المعلومات الأساسية
            </h3>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Title -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        العنوان <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="title" value="<?php echo e(old('title')); ?>"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="مثال: دورات جديدة متاحة!" required>
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Subtitle -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        العنوان الفرعي
                    </label>
                    <input type="text" name="subtitle" value="<?php echo e(old('subtitle')); ?>"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           placeholder="مثال: اكتشف دوراتنا المتخصصة للبكالوريا">
                    <?php $__errorArgs = ['subtitle'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Badge -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        الشارة (Badge)
                    </label>
                    <input type="text" name="badge" value="<?php echo e(old('badge')); ?>"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                           placeholder="مثال: جديد، تحدي، عرض محدود">
                </div>

                <!-- Action Text -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        نص الزر
                    </label>
                    <input type="text" name="action_text" value="<?php echo e(old('action_text')); ?>"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                           placeholder="مثال: اكتشف الآن">
                </div>
            </div>
        </div>

        <!-- Visual Style Card -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <h3 class="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
                <i class="fas fa-palette text-purple-500"></i>
                المظهر والتصميم
            </h3>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Icon Name -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        اسم الأيقونة (Material Icon)
                    </label>
                    <select name="icon_name" class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">اختر أيقونة...</option>
                        <option value="school" <?php echo e(old('icon_name') == 'school' ? 'selected' : ''); ?>>school - مدرسة</option>
                        <option value="emoji_events" <?php echo e(old('icon_name') == 'emoji_events' ? 'selected' : ''); ?>>emoji_events - كأس</option>
                        <option value="assignment" <?php echo e(old('icon_name') == 'assignment' ? 'selected' : ''); ?>>assignment - مهمة</option>
                        <option value="people" <?php echo e(old('icon_name') == 'people' ? 'selected' : ''); ?>>people - أشخاص</option>
                        <option value="calendar_month" <?php echo e(old('icon_name') == 'calendar_month' ? 'selected' : ''); ?>>calendar_month - تقويم</option>
                        <option value="celebration" <?php echo e(old('icon_name') == 'celebration' ? 'selected' : ''); ?>>celebration - احتفال</option>
                        <option value="star" <?php echo e(old('icon_name') == 'star' ? 'selected' : ''); ?>>star - نجمة</option>
                        <option value="bolt" <?php echo e(old('icon_name') == 'bolt' ? 'selected' : ''); ?>>bolt - صاعقة</option>
                        <option value="rocket" <?php echo e(old('icon_name') == 'rocket' ? 'selected' : ''); ?>>rocket - صاروخ</option>
                        <option value="book" <?php echo e(old('icon_name') == 'book' ? 'selected' : ''); ?>>book - كتاب</option>
                    </select>
                </div>

                <!-- Image Upload -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        رفع صورة
                    </label>
                    <div class="relative">
                        <input type="file" name="image" id="imageInput" accept="image/*"
                               class="hidden">
                        <label for="imageInput"
                               class="flex items-center justify-center gap-2 w-full px-4 py-3 border-2 border-dashed border-gray-300 rounded-xl cursor-pointer hover:border-blue-500 hover:bg-blue-50/50 transition-all">
                            <i class="fas fa-cloud-upload-alt text-gray-400"></i>
                            <span class="text-gray-500">اختر صورة أو اسحبها هنا</span>
                        </label>
                        <p class="mt-1 text-xs text-gray-400">PNG, JPG, GIF, WebP - حد أقصى 2MB</p>
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-500"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- Image Preview -->
                    <div id="imagePreviewContainer" class="mt-3 hidden">
                        <div class="relative inline-block">
                            <img id="imagePreview" src="" alt="معاينة" class="w-24 h-24 object-cover rounded-xl border border-gray-200">
                            <button type="button" id="removeImage" class="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600 transition-colors">
                                <i class="fas fa-times text-xs"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- OR External URL -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        أو رابط صورة خارجي
                    </label>
                    <input type="url" name="image_url" id="imageUrlInput" value="<?php echo e(old('image_url')); ?>" dir="ltr"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                           placeholder="https://example.com/image.png">
                    <p class="mt-1 text-xs text-gray-400">سيتم استخدام الصورة المرفوعة إذا تم تحديدها، وإلا سيتم استخدام الرابط</p>
                </div>

                <!-- Gradient Start -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        لون التدرج (البداية)
                    </label>
                    <div class="flex gap-3">
                        <input type="color" name="gradient_start" value="<?php echo e(old('gradient_start', '#3B82F6')); ?>"
                               class="w-14 h-12 rounded-lg border border-gray-200 cursor-pointer">
                        <input type="text" id="gradient_start_text" value="<?php echo e(old('gradient_start', '#3B82F6')); ?>" dir="ltr"
                               class="flex-1 px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono"
                               placeholder="#3B82F6">
                    </div>
                </div>

                <!-- Gradient End -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        لون التدرج (النهاية)
                    </label>
                    <div class="flex gap-3">
                        <input type="color" name="gradient_end" value="<?php echo e(old('gradient_end', '#1D4ED8')); ?>"
                               class="w-14 h-12 rounded-lg border border-gray-200 cursor-pointer">
                        <input type="text" id="gradient_end_text" value="<?php echo e(old('gradient_end', '#1D4ED8')); ?>" dir="ltr"
                               class="flex-1 px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono"
                               placeholder="#1D4ED8">
                    </div>
                </div>

                <!-- Preview -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">معاينة التدرج</label>
                    <div id="gradientPreview" class="h-20 rounded-xl shadow-inner" style="background: linear-gradient(135deg, #3B82F6, #1D4ED8);"></div>
                </div>
            </div>
        </div>

        <!-- Action Card -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <h3 class="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
                <i class="fas fa-link text-green-500"></i>
                الإجراء عند النقر
            </h3>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Action Type -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        نوع الإجراء <span class="text-red-500">*</span>
                    </label>
                    <select name="action_type" id="actionType" required
                            class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="route" <?php echo e(old('action_type', 'route') == 'route' ? 'selected' : ''); ?>>مسار داخلي (Route)</option>
                        <option value="url" <?php echo e(old('action_type') == 'url' ? 'selected' : ''); ?>>رابط خارجي (URL)</option>
                        <option value="none" <?php echo e(old('action_type') == 'none' ? 'selected' : ''); ?>>بدون إجراء</option>
                    </select>
                </div>

                <!-- Route Dropdown (for internal routes) -->
                <div id="routeSelectContainer">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        اختر المسار
                    </label>
                    <select id="routeSelect" class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                        <option value="">اختر مسار من التطبيق...</option>
                        <?php $__currentLoopData = $availableRoutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($route); ?>" <?php echo e(old('action_value') == $route ? 'selected' : ''); ?>><?php echo e($label); ?> (<?php echo e($route); ?>)</option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- URL Input (for external links) -->
                <div id="urlInputContainer" class="hidden">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        الرابط الخارجي
                    </label>
                    <input type="url" id="urlInput" value="<?php echo e(old('action_value')); ?>" dir="ltr"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                           placeholder="https://example.com">
                </div>

                <!-- Hidden action_value field -->
                <input type="hidden" name="action_value" id="actionValue" value="<?php echo e(old('action_value')); ?>">
            </div>
        </div>

        <!-- Settings Card -->
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
            <h3 class="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
                <i class="fas fa-cog text-gray-500"></i>
                الإعدادات
            </h3>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Display Order -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        ترتيب العرض
                    </label>
                    <input type="number" name="display_order" value="<?php echo e(old('display_order', 1)); ?>" min="0"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>

                <!-- Starts At -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        تاريخ البدء (اختياري)
                    </label>
                    <input type="datetime-local" name="starts_at" value="<?php echo e(old('starts_at')); ?>"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>

                <!-- Ends At -->
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">
                        تاريخ الانتهاء (اختياري)
                    </label>
                    <input type="datetime-local" name="ends_at" value="<?php echo e(old('ends_at')); ?>"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>

                <!-- Is Active -->
                <div class="md:col-span-3">
                    <label class="flex items-center gap-3 cursor-pointer">
                        <input type="checkbox" name="is_active" value="1" <?php echo e(old('is_active', true) ? 'checked' : ''); ?>

                               class="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                        <span class="font-semibold text-gray-700">تفعيل العرض فوراً</span>
                    </label>
                </div>
            </div>
        </div>

        <!-- Submit Buttons -->
        <div class="flex items-center justify-between">
            <a href="<?php echo e(route('admin.promos.index')); ?>"
               class="px-6 py-3 border border-gray-200 rounded-xl hover:bg-gray-50 transition-colors">
                <i class="fas fa-arrow-right ml-2"></i>
                رجوع
            </a>
            <button type="submit"
                    class="px-8 py-3 bg-gradient-to-l from-blue-600 to-purple-600 text-white rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all shadow-lg shadow-blue-500/25">
                <i class="fas fa-save ml-2"></i>
                حفظ العرض
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Gradient color sync
    const gradientStart = document.querySelector('input[name="gradient_start"]');
    const gradientEnd = document.querySelector('input[name="gradient_end"]');
    const gradientStartText = document.getElementById('gradient_start_text');
    const gradientEndText = document.getElementById('gradient_end_text');
    const gradientPreview = document.getElementById('gradientPreview');

    function updatePreview() {
        gradientPreview.style.background = `linear-gradient(135deg, ${gradientStart.value}, ${gradientEnd.value})`;
    }

    gradientStart.addEventListener('input', function() {
        gradientStartText.value = this.value;
        updatePreview();
    });

    gradientEnd.addEventListener('input', function() {
        gradientEndText.value = this.value;
        updatePreview();
    });

    gradientStartText.addEventListener('input', function() {
        if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
            gradientStart.value = this.value;
            updatePreview();
        }
    });

    gradientEndText.addEventListener('input', function() {
        if (/^#[0-9A-Fa-f]{6}$/.test(this.value)) {
            gradientEnd.value = this.value;
            updatePreview();
        }
    });

    // Action type change
    const actionType = document.getElementById('actionType');
    const routeSelectContainer = document.getElementById('routeSelectContainer');
    const urlInputContainer = document.getElementById('urlInputContainer');
    const routeSelect = document.getElementById('routeSelect');
    const urlInput = document.getElementById('urlInput');
    const actionValue = document.getElementById('actionValue');

    function updateActionFields() {
        const type = actionType.value;

        if (type === 'route') {
            routeSelectContainer.classList.remove('hidden');
            urlInputContainer.classList.add('hidden');
            actionValue.value = routeSelect.value;
        } else if (type === 'url') {
            routeSelectContainer.classList.add('hidden');
            urlInputContainer.classList.remove('hidden');
            actionValue.value = urlInput.value;
        } else {
            routeSelectContainer.classList.add('hidden');
            urlInputContainer.classList.add('hidden');
            actionValue.value = '';
        }
    }

    actionType.addEventListener('change', updateActionFields);
    routeSelect.addEventListener('change', function() {
        actionValue.value = this.value;
    });
    urlInput.addEventListener('input', function() {
        actionValue.value = this.value;
    });

    // Initialize
    updateActionFields();

    // Image upload preview
    const imageInput = document.getElementById('imageInput');
    const imagePreviewContainer = document.getElementById('imagePreviewContainer');
    const imagePreview = document.getElementById('imagePreview');
    const removeImage = document.getElementById('removeImage');
    const imageUrlInput = document.getElementById('imageUrlInput');

    imageInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            // Validate file size (2MB max)
            if (file.size > 2 * 1024 * 1024) {
                alert('حجم الملف يجب أن لا يتجاوز 2MB');
                this.value = '';
                return;
            }

            const reader = new FileReader();
            reader.onload = function(e) {
                imagePreview.src = e.target.result;
                imagePreviewContainer.classList.remove('hidden');
                // Clear URL input when file is selected
                imageUrlInput.value = '';
            }
            reader.readAsDataURL(file);
        }
    });

    removeImage.addEventListener('click', function() {
        imageInput.value = '';
        imagePreviewContainer.classList.add('hidden');
        imagePreview.src = '';
    });

    // Drag and drop support
    const dropZone = document.querySelector('label[for="imageInput"]');

    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => {
            dropZone.classList.add('border-blue-500', 'bg-blue-50');
        });
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => {
            dropZone.classList.remove('border-blue-500', 'bg-blue-50');
        });
    });

    dropZone.addEventListener('drop', function(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        if (files.length) {
            imageInput.files = files;
            imageInput.dispatchEvent(new Event('change'));
        }
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Dev2026\0\app bac 2\memo_api\resources\views/admin/promos/create.blade.php ENDPATH**/ ?>